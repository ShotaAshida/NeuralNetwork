import funcs
import numpy as np
from mnist import MNIST

# テストデータ
mndata = MNIST("/Users/omushota/ex4-image/le4nn")
X, Y = mndata.load_testing()
X = np.array(X)
X = X.reshape((X.shape[0], 28, 28))
Y = np.array(Y)

# パラメータの読み込み
weightfile = np.load('parameters.npz')

# 定数設定
line = X.shape[0]
row = X.shape[1]
counter = 0

# テスト
learn = np.reshape(np.array(X), (line, row * row)).T
answer = Y

# 入力受け取り
while True:
    strnum = input("input number : ")
    print("")
    num = int(strnum)
    if (num < 0) or (num > 9999):
        print("Please type 0 ~ 9999")
    else:
        break


# 中間層################################
# 定数
middle = 300

# 重み1
weight1 = weightfile['w1']
b1 = weightfile['b1']

# 中間層への入力
midinput = weight1.dot(learn) + b1

# シグモイド
midout = funcs.sigmoid(midinput)

# 出力層##################################
# 定数
end = 10

# 重み2
weight2 = weightfile['w2']
b2 = weightfile['b2']

# 出力層への入力
fininput = weight2.dot(midout) + b2

# ソフトマックス
finout = funcs.softmax(fininput)

indexmax = finout.argmax(axis=0)
Tindexmax = indexmax[num]
ans = Y[num]

print("結果 ")
print(Tindexmax)
print("答え ")
print(ans)
print("")

power = indexmax - Y
counter = len(np.where(power == 0)[0])

print("10000 枚の正答率")
print((counter / 10000.0) * 100.0)
